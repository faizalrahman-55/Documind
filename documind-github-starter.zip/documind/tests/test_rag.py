from rag import DocumentChunk, chunk_text, retrieve_chunks


def test_chunk_text_returns_empty_for_blank_text():
    assert chunk_text("  \n", source="notes.txt") == []


def test_chunk_text_keeps_source_and_overlap():
    result = chunk_text("one two three four five six", source="notes.txt", chunk_size=4, overlap=1)
    assert [c.text for c in result] == ["one two three four", "four five six"]
    assert all(c.source == "notes.txt" for c in result)


def test_chunk_text_rejects_invalid_overlap():
    try:
        chunk_text("words", source="x.txt", chunk_size=3, overlap=3)
    except ValueError as exc:
        assert "overlap" in str(exc)
    else:
        raise AssertionError("Expected ValueError")


def test_retrieve_chunks_finds_relevant_passage():
    chunks = [
        DocumentChunk("one.txt", "The garden needs water and sunlight for plants."),
        DocumentChunk("two.txt", "The API server handles HTTP requests and JSON responses."),
    ]
    result = retrieve_chunks("How do plants grow?", chunks, top_k=1)
    assert len(result) == 1
    assert result[0].source == "one.txt"


def test_retrieve_chunks_handles_empty_question():
    assert retrieve_chunks(" ", [DocumentChunk("a.txt", "some text")]) == []
