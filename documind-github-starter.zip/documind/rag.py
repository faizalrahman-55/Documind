"""Small, transparent retrieval helpers for DocuMind."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass(frozen=True)
class DocumentChunk:
    """A piece of extracted document text and its source label."""

    source: str
    text: str


def chunk_text(text: str, source: str, chunk_size: int = 180, overlap: int = 40) -> list[DocumentChunk]:
    """Split text into overlapping word chunks, skipping blank content."""
    if chunk_size < 1:
        raise ValueError("chunk_size must be at least 1")
    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("overlap must be >= 0 and smaller than chunk_size")

    words = text.split()
    if not words:
        return []

    chunks: list[DocumentChunk] = []
    step = chunk_size - overlap
    for start in range(0, len(words), step):
        piece = " ".join(words[start : start + chunk_size]).strip()
        if piece:
            chunks.append(DocumentChunk(source=source, text=piece))
        if start + chunk_size >= len(words):
            break
    return chunks


def retrieve_chunks(question: str, chunks: Sequence[DocumentChunk], top_k: int = 4) -> list[DocumentChunk]:
    """Return up to top_k chunks ranked by TF-IDF cosine similarity to question."""
    if top_k < 1:
        raise ValueError("top_k must be at least 1")
    if not question.strip() or not chunks:
        return []

    texts = [chunk.text for chunk in chunks]
    vectorizer = TfidfVectorizer(stop_words="english")
    try:
        matrix = vectorizer.fit_transform(texts + [question])
    except ValueError:  # e.g., all text consists only of stop words or punctuation
        return []
    scores = cosine_similarity(matrix[-1], matrix[:-1]).ravel()
    order = scores.argsort()[::-1]
    # Don't return irrelevant passages when all tokens are out of vocabulary.
    ranked = [int(i) for i in order if scores[i] > 0][:top_k]
    return [chunks[i] for i in ranked]
