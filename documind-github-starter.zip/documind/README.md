# DocuMind 📚

**Private document Q&A powered by local AI.** Upload PDFs, Markdown, and text files, retrieve relevant passages, and ask a local language model questions about them.

> This is a portfolio / learning project, not a production document-management system. Always verify answers against the source passages.

## Features

- Local-first workflow: text is sent to your local Ollama instance, not a hosted LLM API.
- PDF, Markdown, and TXT upload.
- Retrieval-augmented generation (RAG-style) using TF-IDF passage retrieval and an Ollama chat model.
- Source labels and expandable retrieved passages for answer checking.
- Configurable Ollama URL, model name, and number of retrieved passages.
- Unit tests and a GitHub Actions workflow.

## Architecture

1. **Ingest:** extract text from each uploaded file (PDF pages stay separately labelled).
2. **Chunk:** split text into overlapping passages.
3. **Retrieve:** rank passages against the question with TF-IDF cosine similarity.
4. **Generate:** send the question plus top passages to a local Ollama model.
5. **Inspect:** show retrieved passages so you can validate the response.

## Requirements

- Python 3.10 or newer
- [Ollama](https://ollama.com/) installed and running locally
- A model available in Ollama, such as `llama3.2`

## Run locally

### 1. Get the code

```bash
git clone https://github.com/YOUR_USERNAME/documind.git
cd documind
```

Or download this repository as a ZIP and extract it.

### 2. Create a virtual environment

**Windows PowerShell:**

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

**macOS / Linux:**

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

### 3. Start a local model

Install Ollama from [ollama.com](https://ollama.com/), then run:

```bash
ollama pull llama3.2
```

Keep Ollama running. The app defaults to `http://localhost:11434` and model `llama3.2`.

### 4. Start DocuMind

```bash
streamlit run app.py
```

Streamlit prints a local URL, usually `http://localhost:8501`. Open it in your browser, upload documents, click **Index documents**, and ask a question.

### 5. Run tests

```bash
pytest -q
```

## Limitations

- Scanned, image-only PDFs are not OCR-processed.
- TF-IDF retrieval is a simple baseline; it is not a semantic embedding model.
- Model quality and speed depend on your local hardware and chosen Ollama model.
- The app currently keeps the index in Streamlit session memory. Refreshing or restarting may require indexing again.
- Do not use it as the sole basis for legal, medical, financial, or other high-stakes decisions.

## Roadmap

- [ ] Add semantic embeddings and persistent vector storage.
- [ ] Add DOCX support and OCR for scanned PDFs.
- [ ] Add chat history and answer-quality evaluation.
- [ ] Add Docker support and a deployment guide.
- [ ] Add a demo GIF / screenshots.

## Contributing

Issues and pull requests are welcome. For substantial changes, open an issue first to discuss the proposal. Please add tests for new functionality.

## License

MIT. See [LICENSE](LICENSE).
